import { Smartphone, Laptop, Shirt, Home, Car, Book, Gamepad2, Heart } from 'lucide-react'
import { Card } from './ui/card'

const categories = [
  { id: 1, name: 'الإلكترونيات', icon: Smartphone, color: 'bg-blue-50 hover:bg-blue-100' },
  { id: 2, name: 'الكمبيوتر', icon: Laptop, color: 'bg-green-50 hover:bg-green-100' },
  { id: 3, name: 'الأزياء', icon: Shirt, color: 'bg-pink-50 hover:bg-pink-100' },
  { id: 4, name: 'المنزل والحديقة', icon: Home, color: 'bg-orange-50 hover:bg-orange-100' },
  { id: 5, name: 'السيارات', icon: Car, color: 'bg-red-50 hover:bg-red-100' },
  { id: 6, name: 'الكتب', icon: Book, color: 'bg-purple-50 hover:bg-purple-100' },
  { id: 7, name: 'الألعاب', icon: Gamepad2, color: 'bg-indigo-50 hover:bg-indigo-100' },
  { id: 8, name: 'الصحة والجمال', icon: Heart, color: 'bg-rose-50 hover:bg-rose-100' },
]

export function Categories() {
  return (
    <section className="py-8 bg-muted/30">
      <div className="container mx-auto px-4">
        <h2 className="text-center mb-8">تسوق حسب الفئة</h2>
        <div className="grid grid-cols-2 md:grid-cols-4 lg:grid-cols-8 gap-4">
          {categories.map((category) => {
            const Icon = category.icon
            return (
              <Card 
                key={category.id}
                className={`${category.color} border-none cursor-pointer transition-colors p-4 text-center hover:shadow-md`}
              >
                <Icon className="h-8 w-8 mx-auto mb-2 text-gray-700" />
                <p className="text-sm">{category.name}</p>
              </Card>
            )
          })}
        </div>
      </div>
    </section>
  )
}