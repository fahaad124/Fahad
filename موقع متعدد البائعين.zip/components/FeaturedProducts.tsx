import { ProductCard } from './ProductCard'

const featuredProducts = [
  {
    id: 1,
    name: 'آيفون 15 برو ماكس 256 جيجا - تيتانيوم طبيعي',
    price: 4999,
    originalPrice: 5499,
    image: 'https://images.unsplash.com/photo-1592750475338-74b7b21085ab?w=400&h=300&fit=crop',
    rating: 5,
    reviews: 128,
    vendor: 'متجر التقنية المتقدمة',
    discount: 9,
    isNew: true
  },
  {
    id: 2,
    name: 'لابتوب ماك بوك إير M2 - 13.6 إنش - رمادي فضائي',
    price: 3899,
    image: 'https://images.unsplash.com/photo-1541807084-5c52b6b3adef?w=400&h=300&fit=crop',
    rating: 4,
    reviews: 89,
    vendor: 'عالم الكمبيوتر'
  },
  {
    id: 3,
    name: 'ساعة ذكية سامسونج جالاكسي واتش 6 - 44 مم',
    price: 1299,
    originalPrice: 1599,
    image: 'https://images.unsplash.com/photo-1523275335684-37898b6baf30?w=400&h=300&fit=crop',
    rating: 4,
    reviews: 156,
    vendor: 'متجر الساعات الذكية',
    discount: 19
  },
  {
    id: 4,
    name: 'سماعات أبل إيربودز برو الجيل الثاني',
    price: 899,
    image: 'https://images.unsplash.com/photo-1606220945770-b5b6c2c55bf1?w=400&h=300&fit=crop',
    rating: 5,
    reviews: 234,
    vendor: 'متجر الصوتيات المتميز'
  },
  {
    id: 5,
    name: 'تيشيرت قطني عالي الجودة - أزرق داكن',
    price: 89,
    originalPrice: 119,
    image: 'https://images.unsplash.com/photo-1521572163474-6864f9cf17ab?w=400&h=300&fit=crop',
    rating: 4,
    reviews: 67,
    vendor: 'أزياء النخبة',
    discount: 25
  },
  {
    id: 6,
    name: 'حقيبة ظهر جلدية فاخرة - بني',
    price: 299,
    image: 'https://images.unsplash.com/photo-1553062407-98eeb64c6a62?w=400&h=300&fit=crop',
    rating: 5,
    reviews: 45,
    vendor: 'متجر الحقائب الأنيقة'
  },
  {
    id: 7,
    name: 'كتاب تعلم البرمجة بـ React - الإصدار الجديد',
    price: 149,
    image: 'https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?w=400&h=300&fit=crop',
    rating: 5,
    reviews: 89,
    vendor: 'مكتبة المبرمجين',
    isNew: true
  },
  {
    id: 8,
    name: 'كرسي مكتب مريح - أسود مع مساند ذراعين',
    price: 799,
    originalPrice: 999,
    image: 'https://images.unsplash.com/photo-1586023492125-27b2c045efd7?w=400&h=300&fit=crop',
    rating: 4,
    reviews: 78,
    vendor: 'أثاث المكاتب العصري',
    discount: 20
  }
]

export function FeaturedProducts() {
  return (
    <section className="py-12">
      <div className="container mx-auto px-4">
        <h2 className="text-center mb-8">المنتجات المميزة</h2>
        <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 lg:grid-cols-4 gap-6">
          {featuredProducts.map((product) => (
            <ProductCard key={product.id} product={product} />
          ))}
        </div>
      </div>
    </section>
  )
}