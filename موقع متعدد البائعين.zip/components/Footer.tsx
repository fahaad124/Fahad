import { Globe, Facebook, Twitter, Instagram, Mail, Phone, MapPin } from 'lucide-react'
import { Button } from './ui/button'
import { Input } from './ui/input'
import { Separator } from './ui/separator'

export function Footer() {
  return (
    <footer className="bg-muted/30 border-t">
      <div className="container mx-auto px-4 py-12">
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-8" dir="rtl">
          {/* Company Info */}
          <div className="text-right">
            <div className="flex items-center justify-end gap-2 mb-4">
              <span className="font-bold text-lg">سوق البائعين</span>
              <div className="h-8 w-8 bg-primary rounded-md flex items-center justify-center">
                <Globe className="h-5 w-5 text-primary-foreground" />
              </div>
            </div>
            <p className="text-muted-foreground mb-4">
              منصة التجارة الإلكترونية الرائدة التي تجمع أفضل البائعين في مكان واحد. 
              نوفر تجربة تسوق آمنة ومريحة لجميع عملائنا.
            </p>
            <div className="flex gap-2 justify-end">
              <Button size="icon" variant="ghost">
                <Facebook className="h-4 w-4" />
              </Button>
              <Button size="icon" variant="ghost">
                <Twitter className="h-4 w-4" />
              </Button>
              <Button size="icon" variant="ghost">
                <Instagram className="h-4 w-4" />
              </Button>
            </div>
          </div>
          
          {/* Quick Links */}
          <div className="text-right">
            <h3 className="font-medium mb-4">روابط سريعة</h3>
            <div className="space-y-2">
              <a href="#" className="block text-muted-foreground hover:text-foreground transition-colors">الرئيسية</a>
              <a href="#" className="block text-muted-foreground hover:text-foreground transition-colors">المنتجات</a>
              <a href="#" className="block text-muted-foreground hover:text-foreground transition-colors">البائعين</a>
              <a href="#" className="block text-muted-foreground hover:text-foreground transition-colors">العروض</a>
              <a href="#" className="block text-muted-foreground hover:text-foreground transition-colors">اتصل بنا</a>
            </div>
          </div>
          
          {/* Support */}
          <div className="text-right">
            <h3 className="font-medium mb-4">الدعم والمساعدة</h3>
            <div className="space-y-2">
              <a href="#" className="block text-muted-foreground hover:text-foreground transition-colors">مركز المساعدة</a>
              <a href="#" className="block text-muted-foreground hover:text-foreground transition-colors">سياسة الاسترداد</a>
              <a href="#" className="block text-muted-foreground hover:text-foreground transition-colors">الشحن والتوصيل</a>
              <a href="#" className="block text-muted-foreground hover:text-foreground transition-colors">الأسئلة الشائعة</a>
              <a href="#" className="block text-muted-foreground hover:text-foreground transition-colors">انضم كبائع</a>
            </div>
          </div>
          
          {/* Contact & Newsletter */}
          <div className="text-right">
            <h3 className="font-medium mb-4">ابق على تواصل</h3>
            <div className="space-y-3 mb-4">
              <div className="flex items-center gap-2 justify-end">
                <span className="text-muted-foreground text-sm">support@souq-sellers.com</span>
                <Mail className="h-4 w-4 text-muted-foreground" />
              </div>
              <div className="flex items-center gap-2 justify-end">
                <span className="text-muted-foreground text-sm">+966 50 123 4567</span>
                <Phone className="h-4 w-4 text-muted-foreground" />
              </div>
              <div className="flex items-center gap-2 justify-end">
                <span className="text-muted-foreground text-sm">الرياض، المملكة العربية السعودية</span>
                <MapPin className="h-4 w-4 text-muted-foreground" />
              </div>
            </div>
            
            <h4 className="font-medium mb-2">النشرة البريدية</h4>
            <div className="flex gap-2" dir="ltr">
              <Button size="sm">اشتراك</Button>
              <Input placeholder="البريد الإلكتروني" className="text-right" dir="rtl" />
            </div>
          </div>
        </div>
        
        <Separator className="my-8" />
        
        <div className="flex flex-col md:flex-row justify-between items-center text-sm text-muted-foreground" dir="rtl">
          <p className="text-right">© 2024 سوق البائعين. جميع الحقوق محفوظة.</p>
          <div className="flex gap-6 mt-4 md:mt-0">
            <a href="#" className="hover:text-foreground transition-colors">سياسة الخصوصية</a>
            <a href="#" className="hover:text-foreground transition-colors">شروط الاستخدام</a>
            <a href="#" className="hover:text-foreground transition-colors">ملفات تعريف الارتباط</a>
          </div>
        </div>
      </div>
    </footer>
  )
}