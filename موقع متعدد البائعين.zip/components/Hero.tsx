import { Button } from './ui/button'
import { Badge } from './ui/badge'
import { ImageWithFallback } from './figma/ImageWithFallback'

export function Hero() {
  return (
    <section className="relative py-20 bg-gradient-to-br from-primary/5 via-background to-secondary/10">
      <div className="container mx-auto px-4">
        <div className="grid lg:grid-cols-2 gap-12 items-center">
          {/* Content */}
          <div className="text-right" dir="rtl">
            <Badge className="mb-4 bg-green-100 text-green-800 hover:bg-green-200">
              أكثر من 10,000 منتج متاح
            </Badge>
            <h1 className="mb-6 text-4xl md:text-5xl lg:text-6xl">
              اكتشف أفضل 
              <span className="text-primary block">المنتجات</span>
              من بائعين موثوقين
            </h1>
            <p className="mb-8 text-xl text-muted-foreground max-w-lg">
              تسوق من آلاف المنتجات عالية الجودة من بائعين معتمدين في مكان واحد. 
              توصيل سريع، أسعار منافسة، وضمان الجودة.
            </p>
            <div className="flex gap-4">
              <Button size="lg" className="px-8">
                ابدأ التسوق الآن
              </Button>
              <Button size="lg" variant="outline" className="px-8">
                انضم كبائع
              </Button>
            </div>
            
            {/* Stats */}
            <div className="grid grid-cols-3 gap-6 mt-12 pt-8 border-t">
              <div className="text-center">
                <div className="text-2xl font-bold text-primary">500+</div>
                <p className="text-sm text-muted-foreground">بائع موثوق</p>
              </div>
              <div className="text-center">
                <div className="text-2xl font-bold text-primary">50k+</div>
                <p className="text-sm text-muted-foreground">عميل راضٍ</p>
              </div>
              <div className="text-center">
                <div className="text-2xl font-bold text-primary">99%</div>
                <p className="text-sm text-muted-foreground">نسبة الرضا</p>
              </div>
            </div>
          </div>
          
          {/* Image */}
          <div className="relative">
            <div className="relative z-10">
              <ImageWithFallback
                src="https://images.unsplash.com/photo-1556742049-0cfed4f6a45d?w=600&h=400&fit=crop"
                alt="تسوق إلكتروني"
                className="rounded-2xl shadow-2xl w-full"
              />
            </div>
            {/* Floating Cards */}
            <div className="absolute -top-4 -left-4 bg-white rounded-lg shadow-lg p-4 z-20">
              <div className="flex items-center gap-3">
                <div className="w-12 h-12 bg-green-100 rounded-full flex items-center justify-center">
                  <span className="text-green-600 text-xl">✓</span>
                </div>
                <div>
                  <p className="font-medium text-sm">توصيل مجاني</p>
                  <p className="text-xs text-muted-foreground">للطلبات أكثر من 200 ريال</p>
                </div>
              </div>
            </div>
            
            <div className="absolute -bottom-4 -right-4 bg-white rounded-lg shadow-lg p-4 z-20">
              <div className="flex items-center gap-3">
                <div className="w-12 h-12 bg-blue-100 rounded-full flex items-center justify-center">
                  <span className="text-blue-600 text-xl">⭐</span>
                </div>
                <div>
                  <p className="font-medium text-sm">جودة مضمونة</p>
                  <p className="text-xs text-muted-foreground">استرداد خلال 30 يوم</p>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </section>
  )
}