import { Star, ShoppingCart, Heart } from 'lucide-react'
import { Card, CardContent, CardFooter } from './ui/card'
import { Button } from './ui/button'
import { Badge } from './ui/badge'
import { ImageWithFallback } from './figma/ImageWithFallback'

interface Product {
  id: number
  name: string
  price: number
  originalPrice?: number
  image: string
  rating: number
  reviews: number
  vendor: string
  discount?: number
  isNew?: boolean
}

interface ProductCardProps {
  product: Product
}

export function ProductCard({ product }: ProductCardProps) {
  return (
    <Card className="overflow-hidden hover:shadow-lg transition-shadow group">
      <div className="relative">
        <ImageWithFallback
          src={product.image}
          alt={product.name}
          className="w-full h-48 object-cover"
        />
        
        {/* Badges */}
        <div className="absolute top-2 left-2 flex flex-col gap-1">
          {product.isNew && (
            <Badge className="bg-green-500 hover:bg-green-600">جديد</Badge>
          )}
          {product.discount && (
            <Badge className="bg-red-500 hover:bg-red-600">
              -{product.discount}%
            </Badge>
          )}
        </div>
        
        {/* Wishlist Button */}
        <Button
          size="icon"
          variant="ghost"
          className="absolute top-2 right-2 h-8 w-8 bg-white/80 hover:bg-white opacity-0 group-hover:opacity-100 transition-opacity"
        >
          <Heart className="h-4 w-4" />
        </Button>
      </div>
      
      <CardContent className="p-4">
        <h3 className="font-medium line-clamp-2 mb-2 text-right" dir="rtl">
          {product.name}
        </h3>
        
        <div className="flex items-center gap-1 mb-2 justify-end" dir="rtl">
          <span className="text-sm text-muted-foreground">({product.reviews})</span>
          <div className="flex">
            {[...Array(5)].map((_, i) => (
              <Star 
                key={i} 
                className={`h-4 w-4 ${
                  i < product.rating ? 'fill-yellow-400 text-yellow-400' : 'text-gray-300'
                }`} 
              />
            ))}
          </div>
        </div>
        
        <p className="text-sm text-muted-foreground mb-2 text-right" dir="rtl">
          بائع: {product.vendor}
        </p>
        
        <div className="flex items-center gap-2 justify-end" dir="rtl">
          <span className="font-bold">{product.price.toLocaleString('ar')} ريال</span>
          {product.originalPrice && (
            <span className="text-sm text-muted-foreground line-through">
              {product.originalPrice.toLocaleString('ar')}
            </span>
          )}
        </div>
      </CardContent>
      
      <CardFooter className="p-4 pt-0">
        <Button className="w-full" dir="rtl">
          <ShoppingCart className="h-4 w-4 ml-2" />
          إضافة للسلة
        </Button>
      </CardFooter>
    </Card>
  )
}